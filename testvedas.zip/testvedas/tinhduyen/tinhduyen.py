import requests
import json
import urllib.parse

# ---------- HÀM GỌI API VEDASTRO ----------
def get_api_base():
    return "https://api.vedastro.org/api/Calculate/"

def get_all_data(name, location, time, date, timezone):
    base_url = get_api_base()

    # Encode location để đưa vào URL (ví dụ: "Việt Nam, Việt Nam" -> "Vi%E1%BB%87t%20Nam%2C%20Vi%E1%BB%87t%20Nam")
    encoded_location = urllib.parse.quote(location, safe='')
    common_path = f"Location/{encoded_location}/Time/{time}/{date}/{timezone}/"

    # 🌙 API cần thiết
    apis = {
        "all_planet_data": f"{base_url}AllPlanetData/PlanetName/Moon/{common_path}",
        "moon_constellation": f"{base_url}MoonConstellation/{common_path}",
        "yoni_kuta": f"{base_url}YoniKutaAnimal/{common_path}", 
    }

    result = {"name": name}
    for key, url in apis.items():
        print(f"🔗 Gọi API: {url}")
        response = requests.get(url)
        if response.status_code == 200:
            try:
                result[key] = response.json()
            except Exception as e:
                result[key] = {"error": f"Lỗi parse JSON: {str(e)}"}
        else:
            result[key] = {"error": f"Lỗi API: {response.status_code}"}
    return result

# ---------- HÀM NHẬP DỮ LIỆU TỪ NGƯỜI DÙNG ----------
def input_person(label):
    print(f"\n📌 Nhập thông tin cho {label}:")
    name = input("Tên: ")
    location = input("Địa điểm sinh (ví dụ: Việt Nam, Việt Nam): ")
    time = input("Giờ sinh (định dạng 24h, ví dụ: 12:00): ")
    date = input("Ngày sinh (định dạng dd/mm/yyyy, ví dụ: 15/06/2003): ")
    timezone = "+07:00"
    return get_all_data(name, location, time, date, timezone)

# ---------- CHẠY CHƯƠNG TRÌNH ----------
if __name__ == "__main__":
    print("🔮 PHÂN TÍCH TÌNH DUYÊN BẰNG DỮ LIỆU CHIÊM TINH (VEDASTRO)\n")

    person_a = input_person("Người A")
    person_b = input_person("Người B")

    love_data = {
        "person_a": person_a,
        "person_b": person_b
    }

    with open("love_analysis_data.json", "w", encoding="utf-8") as f:
        json.dump(love_data, f, ensure_ascii=False, indent=2)

    print("\n✅ Dữ liệu tình duyên đã được lưu vào 'love_analysis_data.json'")
