import json
from openai import OpenAI

# 🔐 API Key của bạn
client = OpenAI(api_key="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")

# 📤 Gửi dữ liệu lên GPT để phân tích
def analyze_love(full_data):
    prompt = f"""
Bạn là chuyên gia chiêm tinh Vệ Đà. Hãy phân tích tình duyên giữa hai người dựa trên dữ liệu chi tiết dưới đây (dữ liệu từ Vedastro API).

Bao gồm:
- Vị trí và tính chất của Mặt Trăng (Moon)
- Tên hành tinh, cung hoàng đạo, nhà ở
- Tính thiện/ác (Nature), sức mạnh (Strength), điểm số (Score)
- Moon Constellation (Chòm sao Mặt Trăng)
- Yoni Kuta Animal (loài tương hợp giới tính)

Yêu cầu:
1. Nhận xét tổng quát về tính cách từng người
2. Đánh giá độ hòa hợp cảm xúc, tinh thần, giới tính
3. Dự đoán mối quan hệ nếu yêu nhau, cưới nhau
4. Kết luận mối quan hệ có bền vững, nên tiến xa không?

Dữ liệu chi tiết JSON:
{json.dumps(full_data, ensure_ascii=False, indent=2)}
"""

    response = client.chat.completions.create(
        model="gpt-4",
        messages=[
            {"role": "system", "content": "Bạn là chuyên gia chiêm tinh học Vệ Đà."},
            {"role": "user", "content": prompt}
        ],
        temperature=0.7
    )
    return response.choices[0].message.content

# === CHẠY CHƯƠNG TRÌNH PHÂN TÍCH ===
if __name__ == "__main__":
    print("🔮 Đang phân tích tình duyên từ file JSON gốc...")

    # Đường dẫn file bạn đã upload
    file_path = "love_analysis_data.json"

    with open(file_path, "r", encoding="utf-8") as f:
        full_raw_data = json.load(f)

    print("📦 Dữ liệu đang gửi GPT")
    # print(json.dumps(full_raw_data, indent=2, ensure_ascii=False))

    result = analyze_love(full_raw_data)

    print("\n===== 💘 KẾT QUẢ PHÂN TÍCH 💘 =====\n")
    print(result)

    # Lưu kết quả
    with open("love_analysis_result.txt", "w", encoding="utf-8") as f:
        f.write(result)
