from openai import OpenAI

# 📂 Đọc dữ liệu từ file
with open("vedastro_trần_minh_mẫn.txt", "r", encoding="utf-8") as file:
    vedastro_content = file.read()

# ✨ Tạo prompt gửi GPT
prompt = f"""
Dưới đây là thông tin 12 cung trong bản đồ chiêm tinh Vệ Đà:
{vedastro_content}

Hãy phân tích từng cung theo:
- Ý nghĩa cung chính
- Chòm sao & chủ tinh ảnh hưởng
- Hành tinh cư ngụ/chiếu
- Sức mạnh của cung
- Tổng kết ảnh hưởng tích cực/tiêu cực

Cuối cùng, đưa ra nhận định tổng quan về lá số một cách dễ hiểu và sinh động.
"""

# 🚀 Gọi GPT
client = OpenAI(api_key="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")  # ← nhập API key thật của bạn

response = client.chat.completions.create(
    model="gpt-3.5-turbo",
    messages=[
        {"role": "user", "content": prompt}
    ],
    temperature=0.7
)

# 📤 In kết quả
print("\n📜 Phân tích chiêm tinh:\n")
print(response.choices[0].message.content)
