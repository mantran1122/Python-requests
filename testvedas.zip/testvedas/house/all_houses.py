import requests
from urllib.parse import quote

# 🔐 API Key Vedastro
VEDASTRO_API_KEY = "aiyGSQb19s"

# 🔧 Hàm dựng URL Vedastro
def build_api_url(location: str, time: str, date: str, timezone: str = "+07:00") -> str:
    location_encoded = quote(location)
    day, month, year = date.split("/")
    return (
        f"https://api.vedastro.org/api/Calculate/AllHouseData/HouseName/All/"
        f"Location/{location_encoded}/"
        f"Time/{time}/{day}/{month}/{year}/{timezone}/"
    )

# 📝 Hàm rút gọn và Việt hóa dữ liệu từng cung
def simplify_house(house_number: int, house_data: dict) -> dict:
    house_key = f"House{house_number}"
    house = house_data[house_key]

    return {
        "Cung": f"Cung {house_number}",
        "Cung chính": f"{house['HouseRasiSign']['Name']} ({house['HouseRasiSign']['DegreesIn']['DegreeMinuteSecond']})",
        "Chòm sao": f"{house['HouseConstellation']} (Chủ tinh: {house['HouseConstellationLord']['Name']})",
        "Chủ tinh": house['LordOfHouse']['Name'],
        "Hành tinh chiếu": ', '.join(house['PlanetsAspectingHouse']) or "Không có",
        "Hành tinh cư ngụ": ', '.join(house['PlanetsInHouse']) or "Không có",
        "Lợi tinh chiếu": "✅" if house['IsBeneficPlanetAspectHouse'] == 'True' else "❌",
        "Hại tinh chiếu": "✅" if house['IsMaleficPlanetAspectHouse'] == 'True' else "❌",
        "Sức mạnh": round(float(house['HouseStrength']), 2)
    }

# 📋 In gọn toàn bộ 12 cung
def print_simplified_all_houses(all_data):
    all_houses = all_data['Payload']['AllHouseData']
    for i, house_dict in enumerate(all_houses, start=1):
        info = simplify_house(i, house_dict)
        print(f"\n🔸 {info['Cung']}")
        print(f"  - Cung chính: {info['Cung chính']}")
        print(f"  - Chòm sao: {info['Chòm sao']}")
        print(f"  - Chủ tinh: {info['Chủ tinh']}")
        print(f"  - Hành tinh chiếu: {info['Hành tinh chiếu']}")
        print(f"  - Hành tinh cư ngụ: {info['Hành tinh cư ngụ']}")
        print(f"  - Lợi tinh chiếu: {info['Lợi tinh chiếu']} | Hại tinh chiếu: {info['Hại tinh chiếu']}")
        print(f"  - Sức mạnh: {info['Sức mạnh']}")

# 🚀 Hàm chính
# 🚀 Hàm chính
def get_vedastro_data():
    print("🔮 Nhập thông tin người dùng:")
    name = input("👤 Tên: ")
    birth_date = input("📅 Ngày sinh (dd/mm/yyyy): ")
    birth_time = input("⏰ Giờ sinh (HH:MM): ")
    birth_place = input("📍 Nơi sinh (ví dụ: Hà Nội, Việt Nam): ")

    url = build_api_url(birth_place, birth_time, birth_date)
    headers = {"Authorization": f"Bearer {VEDASTRO_API_KEY}"}

    print(f"\n🌐 Gửi yêu cầu đến Vedastro:\n{url}\n")

    try:
        response = requests.get(url, headers=headers)
        response.raise_for_status()

        vedastro_data = response.json()
        print(f"✅ Dữ liệu Vedastro trả về cho {name}, sinh ngày {birth_date}:")

        # 📋 Ghi log ra file txt
        all_houses = vedastro_data['Payload']['AllHouseData']
        output_lines = []
        for i, house_dict in enumerate(all_houses, start=1):
            info = simplify_house(i, house_dict)
            output_lines.append(f"🔸 {info['Cung']}")
            output_lines.append(f"  - Cung chính: {info['Cung chính']}")
            output_lines.append(f"  - Chòm sao: {info['Chòm sao']}")
            output_lines.append(f"  - Chủ tinh: {info['Chủ tinh']}")
            output_lines.append(f"  - Hành tinh chiếu: {info['Hành tinh chiếu']}")
            output_lines.append(f"  - Hành tinh cư ngụ: {info['Hành tinh cư ngụ']}")
            output_lines.append(f"  - Lợi tinh chiếu: {info['Lợi tinh chiếu']} | Hại tinh chiếu: {info['Hại tinh chiếu']}")
            output_lines.append(f"  - Sức mạnh: {info['Sức mạnh']}")
            output_lines.append("")

            # In ra màn hình
            print("\n".join(output_lines[-9:]))

        filename = f"vedastro_{name.replace(' ', '_')}.txt"
        with open(filename, "w", encoding="utf-8") as f:
            f.write(f"📄 Dữ liệu chiêm tinh của {name}, sinh ngày {birth_date} tại {birth_place}\n\n")
            f.write("\n".join(output_lines))

        print(f"\n💾 Dữ liệu đã được lưu vào file: {filename}")

    except requests.exceptions.HTTPError as http_err:
        print(f"❌ HTTP lỗi: {http_err}")
    except Exception as err:
        print(f"❌ Lỗi khác: {err}")



# 🧪 Gọi hàm nếu chạy trực tiếp
if __name__ == "__main__":
    get_vedastro_data()
