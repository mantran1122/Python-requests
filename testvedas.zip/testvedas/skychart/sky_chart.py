import requests
from urllib.parse import quote

# 🌀 Tạo URL Vedastro cho Sky Chart dạng GIF
def build_sky_chart_url(location: str, time: str, date: str, timezone: str = "+07:00") -> str:
    location_encoded = quote(location)
    day, month, year = date.split("/")
    return f"https://api.vedastro.org/api/Calculate/SkyChartGIF/Location/{location_encoded}/Time/{time}/{day}/{month}/{year}/{timezone}/"

# 🌟 Gọi API và lưu hình ảnh biểu đồ sao
def generate_sky_chart():
    print("🔮 Nhập thông tin ngày giờ sinh để tạo biểu đồ sao:")
    name = input("👤 Tên: ").strip()
    birth_date = input("📅 Ngày sinh (dd/mm/yyyy): ").strip()
    birth_time = input("⏰ Giờ sinh (HH:MM): ").strip()
    birth_place = input("📍 Nơi sinh (ví dụ: Hà Nội, Việt Nam): ").strip()

    # Tạo URL API
    url = build_sky_chart_url(birth_place, birth_time, birth_date)
    url = requests.utils.requote_uri(url)

    print(f"\n🌐 Gửi yêu cầu đến Vedastro:\n{url}\n")
    response = requests.get(url)

    if response.status_code == 200:
        filename = f"sky_chart_{name.replace(' ', '_')}.gif"
        with open(filename, "wb") as f:
            f.write(response.content)
        print(f"✅ Đã lưu biểu đồ sao vào file: {filename}")
    else:
        print(f"❌ Lỗi khi tải biểu đồ: {response.status_code}")
        print(response.text)

# 🧪 Gọi hàm nếu chạy trực tiếp
if __name__ == "__main__":
    generate_sky_chart()
