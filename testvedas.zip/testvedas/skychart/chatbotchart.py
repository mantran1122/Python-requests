import base64
import os
from openai import OpenAI

# 🔐 API Key của bạn
client = OpenAI(api_key="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")

# 📁 File biểu đồ sao (ảnh)
sky_chart_file_path = "sky_chart_Trần_Minh_Mẫn.gif"

# 🔄 Mã hóa ảnh sang base64
def encode_image_to_base64(file_path):
    with open(file_path, "rb") as image_file:
        return base64.b64encode(image_file.read()).decode('utf-8')

# 📤 Gửi ảnh và yêu cầu GPT-4 Vision phân tích
def ask_gpt_about_sky_chart():
    if not os.path.exists(sky_chart_file_path):
        print(f"❌ Không tìm thấy file: {sky_chart_file_path}")
        return

    image_base64 = encode_image_to_base64(sky_chart_file_path)

    response = client.chat.completions.create(
        model="gpt-4-turbo",
        messages=[
            {"role": "system", "content": "Bạn là chuyên gia chiêm tinh Vệ Đà. Hãy phân tích biểu đồ sao dạng hình tròn người dùng gửi lên."},
            {"role": "user", "content": [
                {"type": "text", "text": "Phân tích biểu đồ sao từ ảnh đính kèm."},
                {"type": "image_url", "image_url": {
                    "url": f"data:image/gif;base64,{image_base64}"
                }}
            ]}
        ],
        max_tokens=1500,
    )

    print("📜 GPT trả lời:")
    print(response.choices[0].message.content)

# 🧪 Chạy
if __name__ == "__main__":
    ask_gpt_about_sky_chart()
