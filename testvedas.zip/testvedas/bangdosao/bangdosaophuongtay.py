import matplotlib.pyplot as plt
import matplotlib.patches as mpatches
import numpy as np
import json

# Tải dữ liệu từ file JSON Vedastro
with open("vedastro_birth_chart_Trần_Minh_Mẫn.json", "r", encoding="utf-8") as f:
    data = json.load(f)

# Danh sách cung hoàng đạo
zodiac_order = ['Aries', 'Taurus', 'Gemini', 'Cancer', 'Leo', 'Virgo',
                'Libra', 'Scorpio', 'Sagittarius', 'Capricorn', 'Aquarius', 'Pisces']

# Lấy vị trí hành tinh từ dữ liệu
planet_data = data["AllPlanetData"]["Payload"]["AllPlanetData"]
planet_positions = {}
for item in planet_data:
    for planet, details in item.items():
        if "PlanetRasiD1Sign" in details:
            deg = float(details["PlanetRasiD1Sign"]["DegreesIn"]["TotalDegrees"])
            sign = details["PlanetRasiD1Sign"]["Name"]
            sign_index = zodiac_order.index(sign)
            full_deg = sign_index * 30 + deg
            planet_positions[planet] = full_deg

# Lấy Ascendant và MC nếu có
asc_mc_data = data.get("HouseCusps", {}).get("Payload", {}).get("CuspList", [])
asc_deg = float(asc_mc_data[0]["Position"]["TotalDegrees"]) if asc_mc_data else 0
mc_deg = float(asc_mc_data[9]["Position"]["TotalDegrees"]) if asc_mc_data else 0
planet_positions["Ascendant"] = asc_deg
planet_positions["Midheaven"] = mc_deg

# Ký hiệu hành tinh
planet_symbols = {
    "Sun": "☉", "Moon": "☽", "Mars": "♂", "Mercury": "☿", "Jupiter": "♃",
    "Venus": "♀", "Saturn": "♄", "Rahu": "☊", "Ketu": "☋",
    "Ascendant": "AC", "Midheaven": "MC"
}

# Tính các góc chiếu
def calculate_aspects(positions, orb=6):
    aspects = []
    aspect_angles = {
        "Conjunction": 0,
        "Opposition": 180,
        "Trine": 120,
        "Square": 90,
        "Sextile": 60
    }
    planet_list = list(positions.items())
    for i in range(len(planet_list)):
        for j in range(i + 1, len(planet_list)):
            name1, deg1 = planet_list[i]
            name2, deg2 = planet_list[j]
            diff = abs(deg1 - deg2)
            if diff > 180:
                diff = 360 - diff
            for asp, angle in aspect_angles.items():
                if abs(diff - angle) <= orb:
                    aspects.append((name1, deg1, name2, deg2, asp))
    return aspects

aspects = calculate_aspects(planet_positions)

# Vẽ biểu đồ
fig, ax = plt.subplots(figsize=(10, 10), subplot_kw={'projection': 'polar'})
ax.set_theta_direction(-1)
ax.set_theta_offset(np.pi / 2)
ax.set_xticks(np.linspace(0, 2 * np.pi, 12, endpoint=False))
ax.set_xticklabels(zodiac_order)
ax.set_yticklabels([])
ax.grid(False)

# Đường chia 12 cung
for i in range(12):
    angle = np.radians(i * 30)
    ax.plot([angle, angle], [0, 1], color='lightgray', linestyle='--')

# Vẽ hành tinh
colors = plt.cm.tab20.colors
for idx, (planet, deg) in enumerate(planet_positions.items()):
    theta = np.radians(360 - deg + 90)
    symbol = planet_symbols.get(planet, planet)
    ax.plot(theta, 0.9, 'o', color=colors[idx % len(colors)], markersize=10)
    ax.text(theta, 1.05, symbol, ha='center', va='center', fontsize=16, color=colors[idx % len(colors)])

# Vẽ góc chiếu
aspect_colors = {
    "Conjunction": "black",
    "Opposition": "red",
    "Trine": "green",
    "Square": "orange",
    "Sextile": "blue"
}
for name1, deg1, name2, deg2, asp in aspects:
    theta1 = np.radians(360 - deg1 + 90)
    theta2 = np.radians(360 - deg2 + 90)
    ax.plot([theta1, theta2], [0.9, 0.9], color=aspect_colors[asp], linewidth=1.2, alpha=0.6)

# Chú thích
legend_patches = [mpatches.Patch(color=color, label=asp) for asp, color in aspect_colors.items()]
ax.legend(handles=legend_patches, bbox_to_anchor=(1.1, 1.05))

ax.set_title("Biểu đồ sao vòng tròn (Western style)\nTrần Minh Mẫn", fontsize=16)
plt.tight_layout()
plt.savefig("birth_chart_tran_minh_man.png", dpi=300)
plt.show()
