import requests
from urllib.parse import quote
import json
import os

# 🚀 Nhập thông tin người dùng
print("🔮 Nhập thông tin người dùng:")
birth_name = input("👤 Tên: ")
birth_date = input("📅 Ngày sinh (dd/mm/yyyy): ")
birth_time = input("⏰ Giờ sinh (HH:MM): ")
birth_place = input("📍 Nơi sinh (ví dụ: Hà Nội, Việt Nam): ")
birth_place_nature = birth_place  # nếu cần có thể cho người dùng nhập riêng
timezone = "+07:00"

# 🔧 Xử lý dữ liệu đầu vào
day, month, year = birth_date.strip().split("/")
location_encoded = quote(birth_place.strip())
location_encoded_nature = quote(birth_place_nature.strip())

base_url = "https://api.vedastro.org/api/Calculate"

# 📌 Danh sách API cần gọi
apis = {
    "AllPlanetData": f"{base_url}/AllPlanetData/PlanetName/All/Location/{location_encoded}/Time/{birth_time}/{day}/{month}/{year}/{timezone}/",
    "AllPlanetOrderedByStrength": f"{base_url}/AllPlanetOrderedByStrength/Location/{location_encoded}/Time/{birth_time}/{day}/{month}/{year}/{timezone}/",
    "PlanetStrength": f"{base_url}/PlanetStrength/PlanetName/All/Location/{location_encoded}/Time/{birth_time}/{day}/{month}/{year}/{timezone}/",
    "PlanetNatureScore": f"{base_url}/PlanetNatureScore/Location/{location_encoded_nature}/Time/{birth_time}/{day}/{month}/{year}/{timezone}/InputPlanet/All/",
    "SkyChartGIF": f"{base_url}/SkyChartGIF/Location/{location_encoded}/Time/{birth_time}/{day}/{month}/{year}/{timezone}/"
}

# 📥 Gọi API và lưu dữ liệu JSON
results = {}
for key, url in apis.items():
    if key == "SkyChartGIF":
        print(f"🖼️ Đang tải ảnh bản đồ sao...")
        try:
            response = requests.get(url)
            if response.status_code == 200:
                # 💾 Lưu ảnh .gif
                gif_filename = f"sky_chart_{birth_name.replace(' ', '_')}.gif"
                with open(gif_filename, "wb") as f:
                    f.write(response.content)
                results[key] = {"image_saved": gif_filename}
                print(f"✅ Đã lưu ảnh biểu đồ sao: {gif_filename}")
            else:
                results[key] = {"error": f"Không thể tải ảnh: {response.status_code}"}
        except Exception as e:
            results[key] = {"error": str(e)}
    else:
        print(f"📡 Đang lấy {key} ...")
        try:
            res = requests.get(url)
            if res.status_code == 200:
                results[key] = res.json()
            else:
                results[key] = {"error": f"Lỗi khi gọi API {key}: {res.status_code}"}
        except Exception as e:
            results[key] = {"error": str(e)}

# 💾 Lưu dữ liệu JSON
json_filename = f"vedastro_birth_chart_{birth_name.replace(' ', '_')}.json"
with open(json_filename, "w", encoding="utf-8") as f:
    json.dump(results, f, ensure_ascii=False, indent=2)

print(f"\n✅ Đã lưu dữ liệu JSON vào: {json_filename}")
