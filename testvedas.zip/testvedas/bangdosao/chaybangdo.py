import json
import math
import matplotlib.pyplot as plt

# 🎯 Đọc file JSON
with open("vedastro_birth_chart_Trần_Minh_Mẫn.json", "r", encoding="utf-8") as f:
    data = json.load(f)
    planet_raw_list = data["AllPlanetData"]["Payload"]["AllPlanetData"]

# 🔍 Trích xuất vị trí hành tinh (D1)
planet_positions = []
for planet_entry in planet_raw_list:
    for planet_name, planet_info in planet_entry.items():
        try:
            sign = planet_info["PlanetRasiD1Sign"]["Name"]
            degrees = float(planet_info["PlanetRasiD1Sign"]["DegreesIn"]["TotalDegrees"])
            planet_positions.append((planet_name, sign, degrees))
        except KeyError:
            continue

# 🧭 Danh sách cung và dịch sang tiếng Việt
zodiac_signs = [
    "Aries", "Taurus", "Gemini", "Cancer", "Leo", "Virgo",
    "Libra", "Scorpio", "Sagittarius", "Capricorn", "Aquarius", "Pisces"
]

zodiac_vi = {
    "Aries": "Bạch Dương", "Taurus": "Kim Ngưu", "Gemini": "Song Tử", "Cancer": "Cự Giải",
    "Leo": "Sư Tử", "Virgo": "Xử Nữ", "Libra": "Thiên Bình", "Scorpio": "Bọ Cạp",
    "Sagittarius": "Nhân Mã", "Capricorn": "Ma Kết", "Aquarius": "Bảo Bình", "Pisces": "Song Ngư"
}

# 🌟 Biểu tượng hành tinh
planet_symbols = {
    "Sun": "☉", "Moon": "☽", "Mars": "♂", "Mercury": "☿", "Jupiter": "♃",
    "Venus": "♀", "Saturn": "♄", "Rahu": "☊", "Ketu": "☋"
}

# 🎨 Màu cho nhóm hành tinh
group_colors = {
    "personal": "gold",         # Sun, Moon, Mercury, Venus, Mars
    "social": "skyblue",        # Jupiter, Saturn
    "transcendental": "violet", # Uranus, Neptune, Pluto (nếu có)
    "node": "gray"              # Rahu, Ketu
}

def get_planet_color(planet):
    if planet in ["Sun", "Moon", "Mercury", "Venus", "Mars"]:
        return group_colors["personal"]
    elif planet in ["Jupiter", "Saturn"]:
        return group_colors["social"]
    elif planet in ["Uranus", "Neptune", "Pluto"]:
        return group_colors["transcendental"]
    elif planet in ["Rahu", "Ketu"]:
        return group_colors["node"]
    else:
        return "white"

# 🪐 Vẽ biểu đồ sao
fig, ax = plt.subplots(figsize=(8, 8), subplot_kw={'projection': 'polar'})
ax.set_theta_direction(-1)
ax.set_theta_offset(math.pi / 2)
ax.set_yticklabels([])

# 🎯 Chia cung hoàng đạo
ax.set_xticks([i * math.pi / 6 for i in range(12)])
ax.set_xticklabels([zodiac_vi[z] for z in zodiac_signs], fontsize=10)

# 📍 Hiển thị hành tinh
for planet, sign, deg in planet_positions:
    index = zodiac_signs.index(sign)
    angle = math.radians(360 - (index * 30 + deg))
    radius = 1
    symbol = planet_symbols.get(planet, planet)
    color = get_planet_color(planet)
    ax.plot(angle, radius, 'o', color=color, markersize=10)
    ax.text(angle, radius + 0.1, symbol, ha='center', va='center', fontsize=14, color=color)

plt.title("🔮 Biểu đồ sao - Trần Minh Mẫn", fontsize=16)
plt.tight_layout()
plt.show()
